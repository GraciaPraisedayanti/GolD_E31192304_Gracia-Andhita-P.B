<?php
class Hello_model extends CI_Model{
    //public $txt = 'Hello World!';
    
    public $alert = 'Hello Wolrd dari CI Model';
    
    public $mahasiswa = [
			["nama"=>"Sendy","nim"=>"E31192254","gol"=>"D"],
			["nama"=>"Iven","nim"=>"E31192255","gol"=>"D"],
			["nama"=>"Yulian","nim"=>"E31192256","gol"=>"D"] 
		];
}
?>