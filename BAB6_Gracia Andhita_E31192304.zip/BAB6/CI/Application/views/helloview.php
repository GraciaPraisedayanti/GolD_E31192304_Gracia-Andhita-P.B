<html>
    <!--<head>Controller dan View</head>-->
    <head><title>Controller, Model dan View</title></head>
<body>
    <!--
    <h2>Hello World CI!</h2>
    <h3>Menggunakan Controller dan View</h3>
    -->
    <h2><?php echo $teks;?></h2>
    <h3>Menggunakan Controller, Model dan View!</h3>
</body>
</html>
